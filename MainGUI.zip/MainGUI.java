
package gui;

import javax.swing.*;
import oop.project.DatabaseManagement;

public class MainGUI {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new LoginPage();
        });
    }
}












