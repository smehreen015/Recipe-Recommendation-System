package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Welcome_Page extends JFrame {
    public Welcome_Page() {
        setTitle("The CookBook");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Background panel with image
        setContentPane(new JLabel(new ImageIcon("src/gui/download (2).jpeg")));  // Make sure the image exists here
        setLayout(new FlowLayout(FlowLayout.CENTER, 100, 200));

        JButton startBtn = new JButton("GET STARTED");
        startBtn.setFont(new Font("Arial", Font.BOLD, 18));
        startBtn.setBackground(Color.DARK_GRAY);
        startBtn.setForeground(Color.WHITE);
        startBtn.setPreferredSize(new Dimension(200, 50));
        add(startBtn);

        startBtn.addActionListener(e -> {
            dispose();
            new LoginPage();  // Proceed to login page
        });

        setVisible(true);
    }
}
