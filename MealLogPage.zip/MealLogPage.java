package gui;

import oop.project.DatabaseManagement;

import javax.swing.*;
import java.awt.*;

public class MealLogPage extends JFrame {
    public MealLogPage(int userId, DatabaseManagement db) {
        setTitle("Log a Meal");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(450, 350);
        setLocationRelativeTo(null);

        
        JPanel content = new JPanel(new GridBagLayout());
        content.setBackground(new Color(255, 165, 0)); 
        content.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        
        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel caloriesLabel = new JLabel("Calories:");
        caloriesLabel.setForeground(Color.BLACK);
        content.add(caloriesLabel, gbc);

        gbc.gridx = 1;
        JTextField calField = new JTextField();
        calField.setBackground(Color.WHITE);
        calField.setForeground(Color.BLACK);
        content.add(calField, gbc);

                gbc.gridx = 0;
        gbc.gridy = 1;
        JLabel infoLabel = new JLabel("Nutritional Info:");
        infoLabel.setForeground(Color.BLACK);
        content.add(infoLabel, gbc);

        gbc.gridx = 1;
        JTextField infoField = new JTextField();
        infoField.setBackground(Color.WHITE);
        infoField.setForeground(Color.BLACK);
        content.add(infoField, gbc);

        
        gbc.gridx = 0;
        gbc.gridy = 2;
        JLabel proteinLabel = new JLabel("Protein (g):");
        proteinLabel.setForeground(Color.BLACK);
        content.add(proteinLabel, gbc);

        gbc.gridx = 1;
        JTextField proteinField = new JTextField();
        proteinField.setBackground(Color.WHITE);
        proteinField.setForeground(Color.BLACK);
        content.add(proteinField, gbc);

        
        gbc.gridx = 0;
        gbc.gridy = 3;
        JLabel carbsLabel = new JLabel("Carbs (g):");
        carbsLabel.setForeground(Color.BLACK);
        content.add(carbsLabel, gbc);

        gbc.gridx = 1;
        JTextField carbsField = new JTextField();
        carbsField.setBackground(Color.WHITE);
        carbsField.setForeground(Color.BLACK);
        content.add(carbsField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        JLabel fatsLabel = new JLabel("Fats (g):");
        fatsLabel.setForeground(Color.BLACK);
        content.add(fatsLabel, gbc);

        gbc.gridx = 1;
        JTextField fatsField = new JTextField();
        fatsField.setBackground(Color.WHITE);
        fatsField.setForeground(Color.BLACK);
        content.add(fatsField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        JLabel nameLabel = new JLabel("Meal Name:");
        nameLabel.setForeground(Color.BLACK);
        content.add(nameLabel, gbc);

        gbc.gridx = 1;
        JTextField nameField = new JTextField();
        nameField.setBackground(Color.WHITE);
        nameField.setForeground(Color.BLACK);
        content.add(nameField, gbc);

        
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;

        JButton logButton = new JButton("Log Meal");
        logButton.setBackground(Color.BLACK);
        logButton.setForeground(new Color(255, 165, 0)); 
        logButton.setFont(new Font("SansSerif", Font.BOLD, 14));
        content.add(logButton, gbc);

        
        logButton.addActionListener(e -> {
            try {
                int calories = Integer.parseInt(calField.getText().trim());
                String info = infoField.getText().trim();
                String mealName = nameField.getText().trim();
                double protein = Double.parseDouble(proteinField.getText().trim());
                double carbs = Double.parseDouble(carbsField.getText().trim());
                double fats = Double.parseDouble(fatsField.getText().trim());

                db.manualLogMeal(userId, calories, mealName, info, protein, carbs, fats, true);
                JOptionPane.showMessageDialog(this, "Meal logged successfully.");
                dispose();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter valid numeric values.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
            }
        });

        setContentPane(content);
        setVisible(true);
    }
}
