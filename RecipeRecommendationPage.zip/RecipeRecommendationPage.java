package gui;

import oop.project.DatabaseManagement;

import javax.swing.*;
import java.awt.*;

public class RecipeRecommendationPage extends JFrame {
    private int userId;
    private DatabaseManagement db;

    public RecipeRecommendationPage(int userId, DatabaseManagement db) {
        this.userId = userId;
        this.db = db;

        setTitle("Recipe Recommendations");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        
        ImageIcon originalIcon = new ImageIcon("src/gui/recipe_banner.jpg");
        
        Image scaled = originalIcon.getImage().getScaledInstance(450, 600, Image.SCALE_SMOOTH);
        final ImageIcon leftIcon = new ImageIcon(scaled);

        JLabel imageLabel = new JLabel(leftIcon);
        imageLabel.setPreferredSize(new Dimension(450, 600));
        imageLabel.setBorder(BorderFactory.createLineBorder(new Color(152, 251, 152), 2));
        add(imageLabel, BorderLayout.WEST);

        
        JPanel rightPanel = new JPanel(new GridBagLayout());
        rightPanel.setBackground(Color.BLACK);
        rightPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        
        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel calLabel = new JLabel("Calorie Limit:");
        calLabel.setForeground(new Color(200, 230, 201));
        calLabel.setFont(calLabel.getFont().deriveFont(Font.BOLD, 14f));
        rightPanel.add(calLabel, gbc);

        
        gbc.gridx = 1;
        JTextField calField = new JTextField();
        calField.setBackground(Color.DARK_GRAY);
        calField.setForeground(Color.WHITE);
        rightPanel.add(calField, gbc);

        
        gbc.gridx = 0;
        gbc.gridy = 1;
        JLabel prefLabel = new JLabel("Preference (e.g. high protein):");
        prefLabel.setForeground(new Color(200, 230, 201));
        prefLabel.setFont(prefLabel.getFont().deriveFont(Font.BOLD, 14f));
        rightPanel.add(prefLabel, gbc);

        
        gbc.gridx = 1;
        JTextField prefField = new JTextField();
        prefField.setBackground(Color.DARK_GRAY);
        prefField.setForeground(Color.WHITE);
        rightPanel.add(prefField, gbc);

        
        gbc.gridx = 0;
        gbc.gridy = 2;
        JLabel ingLabel = new JLabel("Ingredient (optional):");
        ingLabel.setForeground(new Color(200, 230, 201));
        ingLabel.setFont(ingLabel.getFont().deriveFont(Font.BOLD, 14f));
        rightPanel.add(ingLabel, gbc);

        
        gbc.gridx = 1;
        JTextField ingField = new JTextField();
        ingField.setBackground(Color.DARK_GRAY);
        ingField.setForeground(Color.WHITE);
        rightPanel.add(ingField, gbc);

        
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;

        JButton searchButton = new JButton("Search Recommendations");
        searchButton.setBackground(new Color(152, 251, 152));
        searchButton.setForeground(Color.BLACK);
        searchButton.setFont(new Font("SansSerif", Font.BOLD, 14));
        rightPanel.add(searchButton, gbc);

        
        add(rightPanel, BorderLayout.CENTER);

        
        searchButton.addActionListener(e -> {
            try {
                int calorieLimit = Integer.parseInt(calField.getText().trim());
                String preference = prefField.getText().trim();
                String ingredient = ingField.getText().trim();

                RecipeResultsPage resultsPage = new RecipeResultsPage(
                    userId, db, calorieLimit, preference, ingredient, leftIcon
                );
                resultsPage.setVisible(true);
                dispose();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(
                    this,
                    "Please enter a valid number for calorie limit.",
                    "Invalid Input",
                    JOptionPane.ERROR_MESSAGE
                );
            }
        });

        setVisible(true);
    }
}
