package gui;

import oop.project.DatabaseManagement;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class RecipeResultsPage extends JFrame {
    private JTable table;
    private DefaultTableModel model;

    public RecipeResultsPage(int userId,
                             DatabaseManagement db,
                             int calorieLimit,
                             String preference,
                             String ingredient,
                             ImageIcon leftIcon) {
        setTitle("Recipe Results");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JLabel imageLabel = new JLabel(leftIcon);
        imageLabel.setPreferredSize(new Dimension(300, 600));
        imageLabel.setBorder(BorderFactory.createLineBorder(new Color(152, 251, 152), 2));
        add(imageLabel, BorderLayout.WEST);

        String[] columns = {"Name", "Calories", "Protein (g)", "Carbs (g)", "Fats (g)"};
        model = new DefaultTableModel(columns, 0);
        table = new JTable(model);
        table.setBackground(Color.BLACK);
        table.setForeground(new Color(200, 230, 201));   
        table.setGridColor(new Color(200, 230, 201)); 
        table.getTableHeader().setBackground(new Color(152, 251, 152));
        table.getTableHeader().setForeground(Color.BLACK);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(scrollPane, BorderLayout.CENTER);

        db.populateRecipeTable(calorieLimit, preference, ingredient, model);
        if (model.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this,
                "No matching recipes found.",
                "No Results",
                JOptionPane.INFORMATION_MESSAGE
            );
        }

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        bottomPanel.setBackground(new Color(200, 230, 201)); // light sage

        JButton logSelectedButton = new JButton("Log Selected Recipe");
        logSelectedButton.setBackground(Color.BLACK);
        logSelectedButton.setForeground(new Color(200, 230, 201));

        JButton backToInputButton = new JButton("Back to Input");
        backToInputButton.setBackground(Color.BLACK);
        backToInputButton.setForeground(new Color(200, 230, 201));

        JButton backToMenuButton = new JButton("Back to Main Menu");
        backToMenuButton.setBackground(Color.BLACK);
        backToMenuButton.setForeground(new Color(200, 230, 201));

        bottomPanel.add(logSelectedButton);
        bottomPanel.add(backToInputButton);
        bottomPanel.add(backToMenuButton);
        add(bottomPanel, BorderLayout.SOUTH);

        logSelectedButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Please select a recipe to log.");
                return;
            }
            String name = model.getValueAt(selectedRow, 0).toString();
            int cals = (int) model.getValueAt(selectedRow, 1);
            int prot = (int) model.getValueAt(selectedRow, 2);
            int carbs = (int) model.getValueAt(selectedRow, 3);
            int fats = (int) model.getValueAt(selectedRow, 4);

            String infoText = "Protein: " + prot + "g, Carbs: " + carbs + "g, Fats: " + fats + "g";

            int result = JOptionPane.showConfirmDialog(
                this,
                "Log this recipe to your meal log?\n\n" +
                  "Name: " + name + "\n" +
                  "Calories: " + cals + "\n" +
                  infoText,
                "Confirm Log",
                JOptionPane.YES_NO_OPTION
            );
            if (result == JOptionPane.YES_OPTION) {
                db.manualLogMeal(userId, cals, name, infoText, prot, carbs, fats, false);
                JOptionPane.showMessageDialog(this, "Recipe logged successfully.");
            }
        });

        backToInputButton.addActionListener(e -> {
            dispose();
            new RecipeRecommendationPage(userId, db).setVisible(true);
        });

        backToMenuButton.addActionListener(e -> {
            dispose();
            new MainMenuPage(userId, db).setVisible(true);
        });

        setVisible(true);
    }
}
