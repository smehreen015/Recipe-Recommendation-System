package gui;

import oop.project.DatabaseManagement;

import javax.swing.*;
import java.awt.*;

public class SignUpPage extends JFrame {
    public SignUpPage(DatabaseManagement db) {
        setTitle("Sign Up");
        setSize(450, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        
        JPanel content = new JPanel(new GridBagLayout());
        content.setBackground(new Color(255, 140, 0)); 
        content.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

      
        gbc.gridx = 0; gbc.gridy = 0;
        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setForeground(Color.BLACK);
        content.add(nameLabel, gbc);

        JTextField nameField = new JTextField();
        gbc.gridx = 1;
        content.add(nameField, gbc);

     
        gbc.gridx = 0; gbc.gridy = 1;
        JLabel ageLabel = new JLabel("Age:");
        ageLabel.setForeground(Color.BLACK);
        content.add(ageLabel, gbc);

        JTextField ageField = new JTextField();
        gbc.gridx = 1;
        content.add(ageField, gbc);

        
        gbc.gridx = 0; gbc.gridy = 2;
        JLabel genderLabel = new JLabel("Gender:");
        genderLabel.setForeground(Color.BLACK);
        content.add(genderLabel, gbc);

        JTextField genderField = new JTextField();
        gbc.gridx = 1;
        content.add(genderField, gbc);

        
        gbc.gridx = 0; gbc.gridy = 3;
        JLabel weightLabel = new JLabel("Weight (kg):");
        weightLabel.setForeground(Color.BLACK);
        content.add(weightLabel, gbc);

        JTextField weightField = new JTextField();
        gbc.gridx = 1;
        content.add(weightField, gbc);

     
        gbc.gridx = 0; gbc.gridy = 4;
        JLabel heightLabel = new JLabel("Height (cm):");
        heightLabel.setForeground(Color.BLACK);
        content.add(heightLabel, gbc);

        JTextField heightField = new JTextField();
        gbc.gridx = 1;
        content.add(heightField, gbc);

        
        gbc.gridx = 0; gbc.gridy = 5;
        JLabel goalLabel = new JLabel("Goal Weight (kg):");
        goalLabel.setForeground(Color.BLACK);
        content.add(goalLabel, gbc);

        JTextField goalField = new JTextField();
        gbc.gridx = 1;
        content.add(goalField, gbc);

       
        JButton submitBtn = new JButton("Submit");
        submitBtn.setBackground(Color.BLACK);
        submitBtn.setForeground(Color.ORANGE);
        submitBtn.setFont(new Font("SansSerif", Font.BOLD, 14));

        gbc.gridx = 0; gbc.gridy = 6;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;
        content.add(submitBtn, gbc);

        add(content);

        
        submitBtn.addActionListener(e -> {
            try {
                String name = nameField.getText().trim();
                int age = Integer.parseInt(ageField.getText().trim());
                String gender = genderField.getText().trim();
                float weight = Float.parseFloat(weightField.getText().trim());
                float height = Float.parseFloat(heightField.getText().trim());
                float goal = Float.parseFloat(goalField.getText().trim());

                int userId = db.addUser(name, age, gender, weight, height, goal);
                if (userId != -1) {
                    JOptionPane.showMessageDialog(this, "Sign-up successful!");
                    dispose();
                    new MainMenuPage(userId, db).setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(this, "Sign-up failed.");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter valid numbers.");
            }
        });

        setVisible(true);
    }
}
