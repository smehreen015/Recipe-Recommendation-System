package gui;

import oop.project.DatabaseManagement;

import javax.swing.*;
import java.awt.*;

public class LoginPage extends JFrame {
    private JTextField nameField = new JTextField(15);
    private DatabaseManagement db = DatabaseManagement.getInstance();

    public LoginPage() {
        setTitle("Log In");
        setSize(500, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        ImageIcon bgIcon = new ImageIcon("src/gui/banner.jpeg");
        Image img = bgIcon.getImage().getScaledInstance(500, 600, Image.SCALE_SMOOTH);
        bgIcon = new ImageIcon(img);
        JLabel background = new JLabel(bgIcon);
        background.setLayout(new GridBagLayout()); 
        setContentPane(background);

        JPanel overlay = new JPanel(new GridBagLayout());
        overlay.setBackground(new Color(0, 0, 0, 180)); 
        overlay.setPreferredSize(new Dimension(350, 300));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 15, 15, 15);
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        JLabel promptLabel = new JLabel("Enter Your Name");
        promptLabel.setFont(new Font("SansSerif", Font.BOLD, 20));
        promptLabel.setForeground(new Color(255, 140, 0)); 
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        overlay.add(promptLabel, gbc);

        nameField.setFont(new Font("SansSerif", Font.PLAIN, 16));
        nameField.setBackground(Color.BLACK);
        nameField.setForeground(Color.WHITE);
        nameField.setCaretColor(Color.WHITE);
        gbc.gridy = 1;
        overlay.add(nameField, gbc);

        JButton loginBtn = new JButton("Log In");
        loginBtn.setFont(new Font("SansSerif", Font.BOLD, 16));
        loginBtn.setBackground(new Color(255, 140, 0));
        loginBtn.setForeground(Color.BLACK);
        gbc.gridy = 2;
        overlay.add(loginBtn, gbc);

        JButton signUpBtn = new JButton("Sign Up");
        signUpBtn.setFont(new Font("SansSerif", Font.BOLD, 16));
        signUpBtn.setBackground(new Color(255, 140, 0));
        signUpBtn.setForeground(Color.BLACK);
        gbc.gridy = 3;
        overlay.add(signUpBtn, gbc);

        background.add(overlay, new GridBagConstraints());

        loginBtn.addActionListener(e -> {
            String name = nameField.getText().trim();
            int userId = db.getUserIdByName(name);
            if (userId != -1) {
                int choice = JOptionPane.showOptionDialog(
                    this,
                    "Login successful! What would you like to do?",
                    "Welcome",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    new String[]{"Go to Main Menu", "Update Profile"},
                    "Go to Main Menu"
                );

                dispose();
                if (choice == 1) {
                    new ProfileUpdatePage(db, userId).setVisible(true);
                } else {
                    new MainMenuPage(userId, db).setVisible(true);
                }
            } else {
                int result = JOptionPane.showConfirmDialog(
                    this,
                    "User not found. Would you like to sign up?",
                    "Sign Up",
                    JOptionPane.YES_NO_OPTION
                );
                if (result == JOptionPane.YES_OPTION) {
                    dispose();
                    new SignUpPage(db).setVisible(true);
                }
            }
        });

        signUpBtn.addActionListener(e -> {
            dispose();
            new SignUpPage(db).setVisible(true);
        });

        setVisible(true);
    }
}
