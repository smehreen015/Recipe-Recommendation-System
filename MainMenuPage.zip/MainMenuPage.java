package gui;

import oop.project.DatabaseManagement;

import javax.swing.*;
import java.awt.*;

public class MainMenuPage extends JFrame {
    public MainMenuPage(int userId, DatabaseManagement db) {
        setTitle("Main Menu");
        setSize(400, 350);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        
        JPanel mainPanel = new JPanel(new GridLayout(5, 1, 10, 10));
        mainPanel.setBackground(Color.BLACK);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        Font btnFont = new Font("SansSerif", Font.BOLD, 16);
        Color orange = new Color(255, 140, 0);

        JButton recBtn = new JButton("Get Recipe Recommendations");
        recBtn.setFont(btnFont);
        recBtn.setBackground(orange);
        recBtn.setForeground(Color.BLACK);

        JButton logBtn = new JButton("Log a Meal");
        logBtn.setFont(btnFont);
        logBtn.setBackground(orange);
        logBtn.setForeground(Color.BLACK);

        JButton viewBtn = new JButton("Manage Meal Logs");
        viewBtn.setFont(btnFont);
        viewBtn.setBackground(orange);
        viewBtn.setForeground(Color.BLACK);

        JButton profileBtn = new JButton("Update Profile");
        profileBtn.setFont(btnFont);
        profileBtn.setBackground(orange);
        profileBtn.setForeground(Color.BLACK);

        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setFont(btnFont);
        logoutBtn.setBackground(orange);
        logoutBtn.setForeground(Color.BLACK);

        mainPanel.add(recBtn);
        mainPanel.add(logBtn);
        mainPanel.add(viewBtn);
        mainPanel.add(profileBtn);
        mainPanel.add(logoutBtn);

        add(mainPanel);

        
        recBtn.addActionListener(e -> new RecipeRecommendationPage(userId, db).setVisible(true));
        logBtn.addActionListener(e -> new MealLogPage(userId, db).setVisible(true));
        viewBtn.addActionListener(e -> new MealHistoryPage(db, userId).setVisible(true));
        profileBtn.addActionListener(e -> new ProfileUpdatePage(db, userId).setVisible(true));
        logoutBtn.addActionListener(e -> {
            dispose();
            new LoginPage().setVisible(true);
        });

        setVisible(true);
    }
}
