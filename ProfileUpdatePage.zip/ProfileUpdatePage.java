package gui;

import oop.project.DatabaseManagement;

import javax.swing.*;
import java.awt.*;

public class ProfileUpdatePage extends JFrame {
    public ProfileUpdatePage(DatabaseManagement db, int userId) {
        setTitle("Update Profile");
        setSize(450, 350);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        
        JPanel content = new JPanel(new GridBagLayout());
        content.setBackground(new Color(255, 140, 0));
        content.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

       
        gbc.gridx = 0; gbc.gridy = 0;
        JLabel lookupLabel = new JLabel("Name:");
        lookupLabel.setForeground(Color.BLACK);
        content.add(lookupLabel, gbc);

        JTextField nameField = new JTextField();
        gbc.gridx = 1;
        content.add(nameField, gbc);

        
        gbc.gridx = 0; gbc.gridy = 1;
        JLabel ageLabel = new JLabel("New Age:");
        ageLabel.setForeground(Color.BLACK);
        content.add(ageLabel, gbc);

        JTextField ageField = new JTextField();
        gbc.gridx = 1;
        content.add(ageField, gbc);

       
        gbc.gridx = 0; gbc.gridy = 2;
        JLabel genderLabel = new JLabel("New Gender:");
        genderLabel.setForeground(Color.BLACK);
        content.add(genderLabel, gbc);

        JComboBox<String> genderBox = new JComboBox<>(new String[]{"Male", "Female", "Other"});
        gbc.gridx = 1;
        content.add(genderBox, gbc);

        
        gbc.gridx = 0; gbc.gridy = 3;
        JLabel weightLabel = new JLabel("New Weight (kg):");
        weightLabel.setForeground(Color.BLACK);
        content.add(weightLabel, gbc);

        JTextField weightField = new JTextField();
        gbc.gridx = 1;
        content.add(weightField, gbc);

        gbc.gridx = 0; gbc.gridy = 4;
        JLabel heightLabel = new JLabel("New Height (cm):");
        heightLabel.setForeground(Color.BLACK);
        content.add(heightLabel, gbc);

        JTextField heightField = new JTextField();
        gbc.gridx = 1;
        content.add(heightField, gbc);

        gbc.gridx = 0; gbc.gridy = 5;
        JLabel goalLabel = new JLabel("New Goal Weight (kg):");
        goalLabel.setForeground(Color.BLACK);
        content.add(goalLabel, gbc);

        JTextField goalField = new JTextField();
        gbc.gridx = 1;
        content.add(goalField, gbc);

        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        buttonPanel.setBackground(new Color(255, 140, 0));

        JButton updateButton = new JButton("Update Profile");
        updateButton.setBackground(Color.BLACK);
        updateButton.setForeground(new Color(255, 140, 0));

        JButton backButton = new JButton("Back to Main Menu");
        backButton.setBackground(Color.BLACK);
        backButton.setForeground(new Color(255, 140, 0));

        buttonPanel.add(updateButton);
        buttonPanel.add(backButton);

        gbc.gridx = 0; gbc.gridy = 6;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;
        content.add(buttonPanel, gbc);

        
        updateButton.addActionListener(e -> {
            try {
                String lookupName = nameField.getText().trim();
                int foundId = db.getUserIdByName(lookupName);
                if (foundId == -1) {
                    JOptionPane.showMessageDialog(this, "User not found.");
                    return;
                }
                int age = Integer.parseInt(ageField.getText().trim());
                String gender = genderBox.getSelectedItem().toString();
                double weight = Double.parseDouble(weightField.getText().trim());
                double height = Double.parseDouble(heightField.getText().trim());
                double goalWeight = Double.parseDouble(goalField.getText().trim());

                db.updateUser(foundId, age, gender, weight, height, goalWeight);
                JOptionPane.showMessageDialog(this, "Profile updated successfully.");
                dispose();
                new MainMenuPage(userId, db).setVisible(true);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter valid numeric values.");
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error updating profile: " + ex.getMessage());
            }
        });

        
        backButton.addActionListener(e -> {
            dispose();
            new MainMenuPage(userId, db).setVisible(true);
        });

        setContentPane(content);
        setVisible(true);
    }
}
