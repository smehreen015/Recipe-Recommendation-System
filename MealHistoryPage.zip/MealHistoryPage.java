package gui;

import oop.project.DatabaseManagement;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class MealHistoryPage extends JFrame {
    private JTable mealTable;
    private DefaultTableModel tableModel;
    private DatabaseManagement db;
    private int userId;

    public MealHistoryPage(DatabaseManagement db, int userId) {
        this.db = db;
        this.userId = userId;

        setTitle("Meal History");
        setSize(800, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        
        ImageIcon icon = new ImageIcon("src/gui/meal_logs_bg.jpg");
        Image scaledImage = icon.getImage().getScaledInstance(800, 500, Image.SCALE_SMOOTH);
        final ImageIcon backgroundImage = new ImageIcon(scaledImage);

        JLabel backgroundLabel = new JLabel(backgroundImage);
        backgroundLabel.setLayout(new BorderLayout());
        setContentPane(backgroundLabel);

        JPanel overlay = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                // Fill with translucent black
                g.setColor(new Color(0, 0, 0, 150));
                g.fillRect(0, 0, getWidth(), getHeight());
                super.paintComponent(g);
            }
        };
        overlay.setOpaque(false);
        backgroundLabel.add(overlay, BorderLayout.CENTER);

        String[] columnNames = {"Log ID", "Name", "Meal Time", "Calories", "Nutritional Info"};
        tableModel = new DefaultTableModel(columnNames, 0);
        mealTable = new JTable(tableModel) {
            
            @Override
            public Component prepareRenderer(javax.swing.table.TableCellRenderer renderer, int row, int column) {
                Component comp = super.prepareRenderer(renderer, row, column);
                comp.setBackground(new Color(0, 0, 0, 0)); 
                comp.setForeground(Color.WHITE);            
                return comp;
            }
        };
        mealTable.setOpaque(false);
        mealTable.setShowGrid(false);
        mealTable.setIntercellSpacing(new Dimension(0, 0));
        mealTable.setRowHeight(24);

       
        JTableHeader header = mealTable.getTableHeader();
        header.setOpaque(true);
        header.setBackground(new Color(200, 230, 201)); 
        header.setForeground(Color.BLACK);
        header.setFont(header.getFont().deriveFont(Font.BOLD, 14f));

        
        JScrollPane scrollPane = new JScrollPane(mealTable);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, new Color(200, 230, 201)));

        
        overlay.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10)) {
            @Override
            protected void paintComponent(Graphics g) {
                
                g.setColor(new Color(0, 0, 0, 200));
                g.fillRect(0, 0, getWidth(), getHeight());
                super.paintComponent(g);
            }
        };
        buttonPanel.setOpaque(false);
        buttonPanel.setPreferredSize(new Dimension(800, 60));

        JButton editBtn = new JButton("Edit Selected");
        styleButton(editBtn);

        JButton deleteBtn = new JButton("Delete Selected");
        styleButton(deleteBtn);

        JButton refreshBtn = new JButton("Refresh");
        styleButton(refreshBtn);

        JButton backBtn = new JButton("Back to Main Menu");
        styleButton(backBtn);

        buttonPanel.add(editBtn);
        buttonPanel.add(deleteBtn);
        buttonPanel.add(refreshBtn);
        buttonPanel.add(backBtn);

        overlay.add(buttonPanel, BorderLayout.SOUTH);

        loadMealData();

        editBtn.addActionListener(e -> editSelectedMeal());
        deleteBtn.addActionListener(e -> deleteSelectedMeal());
        refreshBtn.addActionListener(e -> loadMealData());
        backBtn.addActionListener(e -> {
            dispose();
            new MainMenuPage(userId, db).setVisible(true);
        });

        setVisible(true);
    }

    private void styleButton(JButton btn) {
        btn.setBackground(new Color(200, 230, 201)); 
        btn.setForeground(Color.BLACK);
        btn.setFont(new Font("SansSerif", Font.BOLD, 13));
        btn.setFocusPainted(false);
    }

    private void loadMealData() {
        tableModel.setRowCount(0);
        try {
            PreparedStatement stmt = db.conn.prepareStatement(
                "SELECT log_id, name, meal_time, calories, nutritional_info FROM meal_logs WHERE user_id = ?"
            );
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int logId = rs.getInt("log_id");
                String name = rs.getString("name");
                String mealTime = rs.getTimestamp("meal_time").toString();
                int calories = rs.getInt("calories");
                String info = rs.getString("nutritional_info");
                tableModel.addRow(new Object[]{logId, name, mealTime, calories, info});
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void editSelectedMeal() {
        int selectedRow = mealTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a meal to edit.");
            return;
        }

        int logId = (int) tableModel.getValueAt(selectedRow, 0);
        String currentName = tableModel.getValueAt(selectedRow, 1).toString();
        String currentCalories = tableModel.getValueAt(selectedRow, 3).toString();
        String currentInfo = tableModel.getValueAt(selectedRow, 4).toString();

        JPanel panel = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                g.setColor(new Color(0, 0, 0, 180));
                g.fillRect(0, 0, getWidth(), getHeight());
                super.paintComponent(g);
            }
        };
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        gbc.gridx = 0; gbc.gridy = 0;
        JLabel nameLabel = new JLabel("New Name:");
        nameLabel.setForeground(new Color(200, 230, 201));
        panel.add(nameLabel, gbc);

        JTextField nameField = new JTextField(currentName);
        gbc.gridx = 1;
        panel.add(nameField, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        JLabel calLabel = new JLabel("New Calories:");
        calLabel.setForeground(new Color(200, 230, 201));
        panel.add(calLabel, gbc);

        JTextField calField = new JTextField(currentCalories);
        gbc.gridx = 1;
        panel.add(calField, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        JLabel infoLabel = new JLabel("New Nutritional Info:");
        infoLabel.setForeground(new Color(200, 230, 201));
        panel.add(infoLabel, gbc);

        JTextField infoField = new JTextField(currentInfo);
        gbc.gridx = 1;
        panel.add(infoField, gbc);

        int result = JOptionPane.showConfirmDialog(
            this,
            panel,
            "Edit Meal Log",
            JOptionPane.OK_CANCEL_OPTION,
            JOptionPane.PLAIN_MESSAGE
        );

        if (result == JOptionPane.OK_OPTION) {
            try {
                int newCal = Integer.parseInt(calField.getText().trim());
                String newName = nameField.getText().trim();
                String newInfo = infoField.getText().trim();

                PreparedStatement stmt = db.conn.prepareStatement(
                    "UPDATE meal_logs SET name=?, calories=?, nutritional_info=? WHERE log_id=?"
                );
                stmt.setString(1, newName);
                stmt.setInt(2, newCal);
                stmt.setString(3, newInfo);
                stmt.setInt(4, logId);
                stmt.executeUpdate();
                loadMealData();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter valid numeric calories.");
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    private void deleteSelectedMeal() {
        int selectedRow = mealTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a meal to delete.");
            return;
        }

        int logId = (int) tableModel.getValueAt(selectedRow, 0);
        int confirm = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to delete this meal log?",
            "Confirm Delete",
            JOptionPane.YES_NO_OPTION
        );
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                PreparedStatement stmt = db.conn.prepareStatement("DELETE FROM meal_logs WHERE log_id=?");
                stmt.setInt(1, logId);
                stmt.executeUpdate();
                loadMealData();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
